package com.example.food;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class RandomActivity3 extends AppCompatActivity {

    private ImageView foodImageView;
    private TextView foodNameTextView;
    private TextView recipeTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_random3);

        foodImageView = findViewById(R.id.foodImageView);
        foodNameTextView = findViewById(R.id.foodNameTextView);
        recipeTextView = findViewById(R.id.recipeTextView);

        // 초기 데이터 가져오기
        fetchRandomMeal();

        // 새로고침 버튼 클릭 이벤트 처리
        findViewById(R.id.refreshButton3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fetchRandomMeal();
            }
        });
        findViewById(R.id.backButton3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RandomActivity3.this, MainActivity2.class);
                startActivity(intent);
            }
        });

    }

    // 새로운 무작위 식사 정보 가져오기
    private void fetchRandomMeal() {
        new FetchRandomMealTask().execute();
    }

    // AsyncTask를 사용하여 무작위 식사 정보 가져오기
    private class FetchRandomMealTask extends AsyncTask<Void, Void, JSONObject> {

        @Override
        protected JSONObject doInBackground(Void... voids) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            JSONObject jsonResponse = null;

            try {
                URL url = new URL("https://www.themealdb.com/api/json/v1/1/filter.php?c=Japanese");
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                StringBuilder stringBuilder = new StringBuilder();
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));

                String line;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line).append('\n');
                }

                jsonResponse = new JSONObject(stringBuilder.toString());
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            return jsonResponse;
        }

        @Override
        protected void onPostExecute(JSONObject jsonResponse) {
            if (jsonResponse != null) {
                try {
                    JSONArray mealsArray = jsonResponse.getJSONArray("meals");
                    JSONObject firstMeal = mealsArray.getJSONObject(0);

                    String imageUrl = firstMeal.getString("strMealThumb");
                    String recipeName = firstMeal.getString("strMeal");
                    String recipeInfo = firstMeal.getString("strInstructions");

                    new DownloadImageTask().execute(imageUrl);
                    foodNameTextView.setText(recipeName);
                    recipeTextView.setText(recipeInfo);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // AsyncTask를 사용하여 이미지 다운로드 처리
    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {

        @Override
        protected Bitmap doInBackground(String... strings) {
            String imageUrl = strings[0];
            Bitmap bitmap = null;
            try {
                InputStream in = new URL(imageUrl).openStream();
                bitmap = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return bitmap;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            if (bitmap != null) {
                foodImageView.setImageBitmap(bitmap);
            }
        }
    }
}