package com.example.simplecalculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etInput;
    private String currentOperator = "";
    private String result = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etInput = findViewById(R.id.etInput);

        setNumericButtonListeners();
        setOperatorButtonListeners();
    }

    private void setNumericButtonListeners() {
        int[] numericButtons = {
                R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4, R.id.btn5,
                R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9, R.id.btnDecimal
        };

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button button = (Button) v;
                etInput.append(button.getText());
            }
        };

        for (int id : numericButtons) {
            findViewById(id).setOnClickListener(listener);
        }
    }

    private void setOperatorButtonListeners() {
        int[] operatorButtons = {
                R.id.btnAdd, R.id.btnSubtract, R.id.btnMultiply, R.id.btnDivide, R.id.btnEquals, R.id.btnClear, R.id.btnBackspace
        };

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button button = (Button) v;
                String operator = button.getText().toString();

                switch (operator) {
                    case "C":
                        etInput.setText("");
                        result = "";
                        break;
                    case "⌫":
                        String currentText = etInput.getText().toString();
                        if (currentText.length() > 0) {
                            etInput.setText(currentText.substring(0, currentText.length() - 1));
                        }
                        break;
                    case "=":
                        calculateResult();
                        break;
                    default:
                        if (result.isEmpty()) {
                            result = etInput.getText().toString();
                        } else {
                            calculateResult();
                        }
                        currentOperator = operator;
                        etInput.setText("");
                        break;
                }
            }
        };

        for (int id : operatorButtons) {
            findViewById(id).setOnClickListener(listener);
        }
    }

    private void calculateResult() {
        String input = etInput.getText().toString();
        if (input.isEmpty() || result.isEmpty() || currentOperator.isEmpty()) {
            return;
        }

        double num1 = Double.parseDouble(result);
        double num2 = Double.parseDouble(input);
        double calculationResult = 0;

        switch (currentOperator) {
            case "+":
                calculationResult = num1 + num2;
                break;
            case "-":
                calculationResult = num1 - num2;
                break;
            case "*":
                calculationResult = num1 * num2;
                break;
            case "/":
                if (num2 != 0) {
                    calculationResult = num1 / num2;
                } else {
                    etInput.setText("Error");
                    result = "";
                    return;
                }
                break;
        }

        result = String.valueOf(calculationResult);
        etInput.setText(result);
        currentOperator = "";
    }
}